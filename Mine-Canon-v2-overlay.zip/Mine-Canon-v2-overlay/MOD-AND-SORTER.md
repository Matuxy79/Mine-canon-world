# Mine Canon - Auto-open hub + Mod sorter (v2)

TASIP // base = your launcher. Added: (A) a real Forge 1.20.1 mod, (B) a dependency-aware mod sorter in the launcher.

## A. In-game mod: `mod/jar/minecanon-1.0.0.jar`
Drop it in `<instance>/mods/` (the launcher's per-age `mods` folder).
- **Auto-opens** the Mine Canon hub on the first title screen of each session (client only).
- **K** opens it any time (rebindable in Controls > Mine Canon).
- Hub: search, **Sort** (Load plan / Name / Category / Dependents / Size), **Show** filter by category, details panel (requires, needed-by, file, size), **Export plan**, **Auto-open ON/OFF** toggle, ENTER THE WORLD.
- Reads the age from `-Dminecanon.age=<1|2|3|4|4+|5>`. The launcher now writes this into each profile's JVM args, so the hub shows the right age and era ceiling.
- Config: `config/minecanon-client.toml` (`autoOpen`, `defaultSort`). Client-side only; servers without it still accept you.
- Build: `cd mod/source && ./gradlew build` (JDK 17+; Forge 1.20.1-47.4.26, official mappings).

## B. Launcher Mods page (new)
Reads `META-INF/mods.toml` from every jar. No extraction, no network.
- **Load plan**: Kahn topological order, dependencies first; ties broken by category then name. Same algorithm as the in-game hub.
- Categories: Core, Library, Optimization, Interface, Content, Canon (same heuristics as the mod).
- Sort cycle: Load plan / Category / Name / Size / Dependents. Category filter. Live search.
- **Diagnostics**: missing mandatory dependency, dependency installed but disabled, duplicate mod id, wrong Minecraft/Forge range, installed version outside a declared range, Fabric/Quilt/NeoForge or unreadable jars, dependency cycles.
- Understands **jar-in-jar** libraries (`META-INF/jarjar`), so e.g. JEI's bundled config library is not a false alarm.
- **Enable / Disable**: renames `x.jar` <-> `x.jar.disabled`. Never deletes; refuses to overwrite.
- **Export load plan** writes `minecanon-load-plan.txt` next to the instance's mods folder.
- Honest limit: Forge 1.20.1 reads only the top-level `mods/` folder and decides load order itself. The "plan" is a diagnostic ordering and a reference, not a rename scheme. Only *declared* dependencies are checked; a mod can still crash for reasons mods.toml does not state.

## Verification
- Launcher SelfTest: 64 / 64 checks pass (41 original + 23 sorter: ordering, edges, TOML multiline, each diagnostic, version ranges, jar-in-jar, toggle safety, age tag in profile). Run: `java -cp "build:.:forge-1.20.1-47.4.26-installer.jar" SelfTest . forge-1.20.1-47.4.26-installer.jar`
- Mod: built reobf, loaded in a production-style Forge 1.20.1-47.4.26 client (Xvfb + software GL) beside 10 real mods; log shows the age line and "Auto-opened the hub"; sort, filter and layout checked by synthetic clicks at GUI scale 2.
- NOT tested: the K hotkey at runtime, real Windows / Microsoft Store paths, Linux/mac launcher flows, GUI scales above 3.

Build the launcher: `python build.py` (Java 17+ JDK, no downloads).
