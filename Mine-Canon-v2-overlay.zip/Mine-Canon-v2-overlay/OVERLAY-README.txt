Overlay for your existing Mine-Canon-John-Matukutire folder (the base you gave me).
Copy these files over it: src/ (adds ModSorter.java, ModsPanel.java; edits LauncherUI, LauncherService, SelfTest),
MineCanonLauncher.jar (rebuilt), mod/ (in-game mod jar + source), screenshots/, MOD-AND-SORTER.md.
Then: python build.py   (optional - the jar is already rebuilt)
